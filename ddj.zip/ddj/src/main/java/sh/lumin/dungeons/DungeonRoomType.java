package sh.lumin.dungeons;


public enum DungeonRoomType {
    ENTRANCE(),
    BASE(),
    FAIRY(true, false),
    PUZZLE(true),
    MINI_BOSS(true),
    EXIT(),
    ;

    public boolean isAutomaticallyPlace() {
        return automaticallyPlace;
    }

    public boolean isRequiresData() {
        return requiresData;
    }

    private boolean requiresData = false;
    private boolean automaticallyPlace = true;

    DungeonRoomType() {}

    DungeonRoomType(boolean requiresData) {
        this.requiresData = requiresData;
    }

    DungeonRoomType(boolean requiresData, boolean automaticallyPlace) {
        this.requiresData = requiresData;
        this.automaticallyPlace = automaticallyPlace;
    }
}
